/* ========================================
 *
 * Copyright Samuel Walsh, 2014
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Samuel Walsh.
 *
 * ========================================
*/
#include <project.h>
#include <mpu6050.h>
#include <stdio.h>

/* ========================================
 *
 * Copyright Samuel Walsh, 2014
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Samuel Walsh.
 *
 * ========================================
*/

/* [] END OF FILE */

#include <project.h>

int main()
{
    char buf[50]; //just to hold text values in for writing to UART
    int j = 0; //for loop increment variable
    
	int16_t CAX, CAY, CAZ; //current acceleration values
	int16_t CGX, CGY, CGZ; //current gyroscope values
    int16_t CT;            //current temperature
    
    float   AXoff, AYoff, AZoff; //accelerometer offset values
    float   GXoff, GYoff, GZoff; //gyroscope offset values
    
    float   Asense, Gsense; //Sensitivty values for accelerometer and gyroscope
    
	I2C_MPU6050_Start();
	SERIAL_Start();
	
    CyGlobalIntEnable;

	MPU6050_init();
	MPU6050_initialize();
	SERIAL_UartPutString(MPU6050_testConnection() ? "MPU6050 connection successful\n\r" : "MPU6050 connection failed\n\n\r");
    
    SERIAL_UartPutString("Starting to calibrate values from sensor..\n\r");
    
    
    //for loop only works when sensor is off
    for(j=0; j<10; j++)
    {
      sprintf(buf, "j = %d \n\r", j);
      SERIAL_UartPutString(buf);
    
      MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ, &CT);
      
      sprintf(buf, "AX:%d, AY:%d, AZ:%d || GX:%d, GY:%d, GZ:%d,\t", CAX,CAY,CAZ,CGX,CGY,CGZ);
      SERIAL_UartPutString(buf);
      SERIAL_UartPutString("\n\r");
      CyDelay(300);
    }
    

    //pure while loop this works fine
    while (1) 
    {
      sprintf(buf, "j = %d \n\r", j);
      SERIAL_UartPutString(buf);
    
      MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ, &CT);
      
      sprintf(buf, "AX:%d, AY:%d, AZ:%d || GX:%d, GY:%d, GZ:%d,\t", CAX,CAY,CAZ,CGX,CGY,CGZ);
      SERIAL_UartPutString(buf);
      SERIAL_UartPutString("\n\r");
      CyDelay(300);
    }
     
    
    while(1){
        int x;
    }
    //From here you will want to look at converting values to angles and then complimentary filters to combine the values
    //and to try and stop the drift which will inevitably happen on the gyroscope...
    
}
